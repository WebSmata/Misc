<?php

	require( "config.php" );
	
	session_start();
	$thispage = isset( $_GET['thispage'] ) ? $_GET['thispage'] : "";

	$content = array();
	$content['sitename'] = strlen(as_option('sitename')) ? as_option('sitename') : SITENAME;
	$plumberid = isset( $_SESSION['loggedin_plumber_id'] ) ? $_SESSION['loggedin_plumber_id'] : "";
	$level = isset( $_SESSION['loggedin_plumber_level'] ) ? $_SESSION['loggedin_plumber_level'] : "";
	$fullname = isset( $_SESSION['loggedin_plumber_name'] ) ? $_SESSION['loggedin_plumber_name'] : "There";
	
	switch ( $thispage ) {
		case 'signin':
			$content['plumber'] = new plumber;
			$content['page'] = array(
					'type' => 'form',
					'action' => 'index.php?thispage='.$thispage,
					'fields' => array( 
						'handle' => array('label' => 'Username:', 'type' => 'text'),				
						'password' => array('label' => 'Password:', 'type' => 'password'),
					),
			
					'buttons' => array('signin' => array('label' => 'Login')),			
				);
			
			$content['title'] = "Login to Your Account";
			if ( isset( $_POST['signin'] ) ) {
				$plumberid = plumber::signinplumber($_POST['handle'], md5($_POST['password']));
				if ($plumberid) {
					header( "Location: index.php?status=welcome" );
				}	else {
					header( "Location: index.php?thispage=signin&&error=loginFailed" );
				}
			}
			break;

		case 'register':
			$content['plumber'] = new plumber;			
			$content['page'] = array(
					'type' => 'form',
					'tags' => ' enctype="multipart/form-data"',
					'action' => 'index.php?thispage='.$thispage,
					'fields' => array( 
						'fullname' => array('label' => 'Your Full Name:', 'type' => 'text', 'tags' => 'required '),
						'image' => array('label' => 'Your Photo:', 'type' => 'file', 'tags' => 'required '),
						'location' => array('label' => 'Your Location:', 'type' => 'text', 'tags' => 'required '),
						'about' => array('label' => 'Tell us about you:', 'type' => 'textarea', 'rows' => 5,'tags' => 'required '),
						'mobile' => array('label' => 'Your Mobile Number:', 'type' => 'text', 'tags' => 'required '),
						'email' => array('label' => 'Your Email Address:', 'type' => 'email', 'tags' => 'required '),
						'handle' => array('label' => 'Your Prefferred Username:', 'type' => 'text', 'tags' => 'required '),
						'password' => array('label' => 'Your Prefferred Password:', 'type' => 'password', 'tags' => 'required '),
					),
							
					'buttons' => array('register' => array('label' => 'Register')),
					'hidden' => array('level' => '1'),
				);
			
			$content['title'] = "Register as Plumber";
			if ( isset( $_POST['register'] ) ) {
				$plumber = new plumber;
				$plumber->storeFormValues( $_POST );
				$plumberid = $plumber->insert();
				if ($plumberid) {
					$_SESSION['loggedin_plumber_level'] = $_POST['level'];
					$_SESSION['loggedin_plumber_name'] = $_POST['fullname'];
					$_SESSION['loggedin_plumber_id'] = $plumberid;
					header( "Location: index.php" );
				} else {
					$content['errorMessage'] = "Unable to register you at the moment. Please try again later.";
				}
			}
			break;
		
		case 'signout';
			session_destroy();
			header( "Location: index.php?thispage=signin" );
			break;
				
		case 'database';
			errMissingTables();
			break;
		  	
		case 'plumbers_all':		
			if ( $plumberid ) $loggedinplumber = isset( $_GET['workshop'] ) ? $_GET['workshop'] : $_SESSION['loggedin_plumber_id'];
			else $loggedinplumber = isset( $_GET['workshop'] ) ? $_GET['workshop'] : 0;
			
			$plumbers = plumber::getList('created', 0, $loggedinplumber);
			$listitems = array();
			foreach ( $plumbers as $plumber ) {
				$image = $plumber->image ? '<img src="'.$plumber->image.'" width="40" height="40" style="border-radius:20px"/>' : '';
				$listitems[$plumber->plumberid] = array($image, $plumber->title, $plumber->place, $plumber->price.' /=', $plumber->views);
			}
			switch ($level) {
				case 3:
					$content['title'] = count($listitems)." posts";	
					break;
					
				case 4:
					$content['title'] = count($listitems)." posts";	
					$content['link'] = '<a href="index.php?thispage=loggedin_plumber_new" style="float:right">New Post</a>';
					break;
					
				case 5:
					$content['title'] = count($listitems)." posts";	
					$content['link'] = '<a href="index.php?thispage=loggedin_plumber_new" style="float:right">New Post</a>';
					break;
				
				default:
					$content['title'] = count($listitems)." posts";	
					break;				
			}
			
			$content['page'] = array(
				'type' => 'table',
				'headers' => array( 'image', 'title', 'place', 'price', 'orders' ), 
				'items' => $listitems,
				'onclick' => 'thispage=loggedin_plumber_view&&plumberid=',
			);
			
			break;
				  			
		case 'plumbers':
			$plumbers = plumber::getList();
			$listitems = array();
			foreach ( $plumbers['results'] as $plumber ) {
				$image = $plumber->image ? '<img src="'.$plumber->image.'" width="40" height="40" style="border-radius:20px"/>' : '';
				$listitems[$plumber->plumberid] = array($image, $plumber->fullname.' ('.$plumber->handle.')', $plumber->mobile, $plumber->email);
			}
			
			$content['title'] = "Available Plumbers";
			$content['page'] = array(
					'type' => 'table',
					'headers' => array( '', 'FullName', 'mobile ', 'email'), 
					'items' => $listitems,
					'onclick' => 'thispage=plumber&&plumberid=',
				);
			break;
				
		case 'plumber':
			$plumber = plumber::getById( (int)$_GET["plumberid"] );
			$links = '';
			if ($plumberid) {
				if ($_SESSION['loggedin_plumber_level'] == 5 && $plumberid != $_GET["plumberid"])
					$links = '<h5><a href="index.php?thispage=edit&&plumberid='.$_GET["plumberid"].'">EDIT PLUMBER</a> | <a href="index.php?thispage=delete&&plumberid='.$_GET["plumberid"].'" onclick="return confirm(\'Oops! Are you sure you want to delete Plumber '. $plumber->fullname.'? This action is irrevesible!\')" >DELETE PLUMBER</a></h5>';
			}
			$content['title'] = 'Plumber '. $plumber->fullname;
			$content['page'] = array(
					'type' => 'viewer',
					'links' => $links,
					'items' => array($plumber->plumberid, $plumber->image, $plumber->fullname, $plumber->location, $plumber->mobile, $plumber->email, $plumber->about),					
				);
				
			break;
		
		case 'delete':
			$plumber = plumber::getById( (int)$_GET["plumberid"] );
			$plumber->delete();
			header( "Location: index.php?thispage=plumbers" );
			break;
			
		case 'account':
			if ( !$plumberid ) header( "Location: index.php" );
			$plumber = plumber::getById( (int)$plumberid );
			$content['title'] = "Edit Your Account";	
			$content['page'] = array(
					'type' => 'form',
					'action' => 'index.php?thispage='.$thispage,
					'fields' => array(
						'fullname' => array('label' => 'Your Full Name:', 'type' => 'text', 'tags' => 'required ', 'value' => $plumber->fullname),
						'location' => array('label' => 'Your Location:', 'type' => 'text', 'tags' => 'required ', 'value' => $plumber->location),
						'about' => array('label' => 'Tell us about you:', 'type' => 'textarea', 'rows' => 5,'tags' => 'required ', 'value' => $plumber->about),
						'mobile' => array('label' => 'Your Mobile Number:', 'type' => 'text', 'tags' => 'required ', 'value' => $plumber->mobile),
						'email' => array('label' => 'Your Email Address:', 'type' => 'email', 'tags' => 'required ', 'value' => $plumber->email),
						'handle' => array('label' => 'Your Prefferred Username:', 'type' => 'text', 'tags' => 'required ', 'value' => $plumber->handle),
					),
					
					'hidden' => array('plumberid' => $plumberid, 'level' => $plumber->level),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
						'cancel' => array('label' => 'Cancel Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$plumber->storeFormValues( $_POST );
				$plumber->update();
				header( "Location: index.php?thispage=plumber&&plumberid=".$plumberid."&&status=changesSaved" );
			} elseif ( isset( $_POST['cancel'] ) ) {
				header( "Location: index.php?thispage=plumber&&plumberid=".$plumberid );
			} 
			break;
		
		case 'edit':
			if ( !$plumberid ) header( "Location: index.php" );
			$plumber = plumber::getById( (int)$_GET["plumberid"] );
			$content['title'] = "Edit This Plumber";	
			$content['page'] = array(
					'type' => 'form',
					'action' => 'index.php?thispage='.$thispage.'&&plumberid='.$plumberid,
					'fields' => array(
						'fullname' => array('label' => 'Your Full Name:', 'type' => 'text', 'tags' => 'required ', 'value' => $plumber->fullname),
						'location' => array('label' => 'Your Location:', 'type' => 'text', 'tags' => 'required ', 'value' => $plumber->location),
						'about' => array('label' => 'Tell us about you:', 'type' => 'textarea', 'rows' => 5,'tags' => 'required ', 'value' => $plumber->about),
						'mobile' => array('label' => 'Your Mobile Number:', 'type' => 'text', 'tags' => 'required ', 'value' => $plumber->mobile),
						'email' => array('label' => 'Your Email Address:', 'type' => 'email', 'tags' => 'required ', 'value' => $plumber->email),
						'handle' => array('label' => 'Your Prefferred Username:', 'type' => 'text', 'tags' => 'required ', 'value' => $plumber->handle),
					),
					
					'hidden' => array('plumberid' => $_GET["plumberid"], 'level' => $plumber->level),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
						'cancel' => array('label' => 'Cancel Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$plumber->storeFormValues( $_POST );
				$plumber->update();
				header( "Location: index.php?thispage=plumber&&plumberid=".$_GET["plumberid"]."&&status=changesSaved" );
			} elseif ( isset( $_POST['cancel'] ) ) {
				header( "Location: index.php?thispage=plumber&&plumberid=".$_GET["plumberid"] );
			} 
			break;
				
		case 'settings':
			if ( !$plumberid ) header( "Location: index.php?thispage=signin" );
			$content['title'] = "Your Site Preferences";
			$content['page'] = array(
					'type' => 'form',
					'action' => 'index.php?thispage='.$thispage,
					'fields' => array( 
						'sitename' => array('label' => 'Site Name:', 'type' => 'text', 'tags' => 'required ', 'value' => $content['sitename']),
					),
					
					'hidden' => array('level' => 1),		
					'buttons' => array(
						'saveChanges' => array('label' => 'Save Changes'),
					),
				);
			
			if ( isset( $_POST['saveChanges'] ) ) {
				$sitename = $_POST['sitename'];
				as_update_option('sitename', $sitename);
				
				$filename = "config.php";
				$lines = file($filename, FILE_IGNORE_NEW_LINES );
				$lines[12] = '	define( "SITENAME", "'.$sitename.'"  );';
				file_put_contents($filename, implode("\n", $lines));
		
				header( "Location: index.php?pg=settings&&status=changesSaved" );
			} 
			break;
					
		default: 
			$search = isset( $_GET['q'] ) ? $_GET['q'] : "";
			$plumbers = plumber::searchThis($search);
			$listitems = array();
			foreach ( $plumbers['results'] as $plumber ) {
				$listitems[] = array($plumber->plumberid, $plumber->image, $plumber->fullname, $plumber->location, $plumber->about);
			}
			
			if ($search) $content['title'] = count($plumbers). ' results found for "'.$search.'"';
			else $content['title'] = SITENAME;
			
			$content['page'] = array(
					'type' => 'search', 
					'items' => $listitems,
				);
				
			if ( isset( $_POST['searchNow'] ) ) {
				$searchthis = $_POST['searchText'];
				header( "Location: index.php?thispage=search&&q=" . $searchthis );
			} 
			break;
	}
	
	require ( CORE . "page.php" );